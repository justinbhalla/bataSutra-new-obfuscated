# your-gut-on-screens-late-night-scrolling-digestion-dec-11-2025.html

A Pen created on CodePen.

Original URL: [https://codepen.io/jbhalla/pen/RNavdyy](https://codepen.io/jbhalla/pen/RNavdyy).

